﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Problem10
{
class Problem10
 {
static void Main(string[] args)
    {
        ;
        int value;
        double result;
        Console.WriteLine("Enter Some Value:");
        value = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("\nSeries Is:\n");
        for (int i = 0; i <= value; i++)
        {
            result = Math.Pow(2, i);
            Console.Write(result);
            Console.Write(" ");
        }
        Console.ReadKey();
    }
}
}
