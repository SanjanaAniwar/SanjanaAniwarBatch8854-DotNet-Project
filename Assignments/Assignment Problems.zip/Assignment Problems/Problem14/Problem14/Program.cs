﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Problem15
{
class Problem15
 {
static void Main(string[] args)
    {
        ;
        char ch;
        int i = 10;
        do
        {
            Console.Write(i);
            Console.Write(" ");
            ch = (char)i;
            Console.WriteLine(ch);
            i++;
        } while (i <= 255);
        Console.ReadKey();
    }
}
}
