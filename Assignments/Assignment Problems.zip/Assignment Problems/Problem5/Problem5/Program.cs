﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Problem5
{
class Problem5
 {
static void Main(string[] args)
    {
        ;
        int value;
        char choice;
        double centimeter, liters, kilometer, kilogram;
        Console.WriteLine("Enter A Digit Value:");
        value = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("\n\n Press Any Of The Given Choices \n I -> convert from inches to centimeters.\n G->convert from gallons to liters.\n M - > convert from mile to kilometer.\n P->convert from pound to kilogram.");
        
         choice = Convert.ToChar(Console.ReadLine());
        switch (choice)
        {
            case 'I':
                centimeter = value / 0.3937; //1 cm is equal is 0.3037 inch
        Console.WriteLine("\n\nIn Centimeters:" + centimeter);
                break;
            case 'i':

                centimeter = value / 0.3937;
                Console.WriteLine("\n\nIn Centimeters:" + centimeter);
                break;
            case 'G':
                liters = value * 3.78; // 1 gallon=3.78 litters
                Console.WriteLine("\n\nIn Litters:" + liters);
                break;
            case 'g':
                liters = value * 3.78; // 1 gallon=3.78 litters
                Console.WriteLine("\n\nIn Litters:" + liters);
                break;
            case 'M':
                kilometer = value * 1.60;
                Console.WriteLine("\n\nIn kilometers:" + kilometer);
                break;
            case 'm':
                kilometer = value * 1.60;
                Console.WriteLine("\n\nIn kilometers:" + kilometer);
                break;
            case 'P':
                kilogram = value * 0.453;
                Console.WriteLine("\n\nIn KiloGrams:" + kilogram);
                break;
            case 'p':
                kilogram = value * 0.453;
                Console.WriteLine("\n\nIn KiloGrams:" + kilogram);
                break;
            default:
                Console.WriteLine("You Enter A Invalid Choice, Please Enter A Valid Choice...!");
                break;
        }
        Console.ReadKey();
    }
}
}
