﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Problem8
{
class Problem8
 {
static void Main(string[] args)
    {
        ;
        string value;
        Console.WriteLine("Enter A Operator:");
        value = Console.ReadLine();
        switch (value)
        {
            case "+":
                Console.WriteLine("This Is Arithmatic Operator:");
                break;
            case "-":
                Console.WriteLine("This Is Arithmatic Operator:");
                break;
            case "*":
                Console.WriteLine("This Is Arithmatic Operator:");
                break;
            case "%":
                Console.WriteLine("This Is Arithmatic Operator:");
                break;
            case "/":
                Console.WriteLine("This Is Arithmatic Operator:");
                break;
            case "&":
                Console.WriteLine("This Is Arithmatic Operator:");
                break;
            case "--":
                Console.WriteLine("This Is Arithmatic Operator:");
                break;
            case "++":
                Console.WriteLine("This Is Arithmatic Operator:");
                break;
            case "|":
                Console.WriteLine("This Is Logical Operator:");
                break;
            case "!":
                Console.WriteLine("This Is Logical Operator:");
                break;
            case "^":
                Console.WriteLine("This Is Logical Operator:");
                break;
            case "&&":
                Console.WriteLine("This Is Logical Operator:");
                break;
            case "||":
                Console.WriteLine("This Is Logical Operator:");
                break;
            case "==":
                Console.WriteLine("This Is Relational Operator:");
                break;
            case "!=":
                Console.WriteLine("This Is Logical Operator:");
                break;
            case "<":
                Console.WriteLine("This Is Logical Operator:");
                break;
            case ">":
                Console.WriteLine("This Is Logical Operator:");
                break;
            case "<=":
                Console.WriteLine("This Is Logical Operator:");
                break;
            case ">=":
                Console.WriteLine("This Is Logical Operator:");
                break;
            case "?":
                Console.WriteLine("This Is Conditional Operator:");
                break;
            default:
                Console.WriteLine("This Is Something Else Operator:");
                break;
        }
        Console.ReadKey();
    }
}
}

