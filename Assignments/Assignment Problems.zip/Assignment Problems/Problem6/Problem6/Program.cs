﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Problem6
{
class Problem6
 {
static void Main(string[] args)
    {
        ;
        int time;
        Console.WriteLine("Enter Time Required For A Worker To Complete A Particular Job In Hours");
            time = Convert.ToInt32(Console.ReadLine());
            if (time >= 2 && time >= 3)
            {
                Console.WriteLine("Worker Efficiency Is Highly Efficient.");
            }
            if (time >= 3 && time >= 4)
            {
                Console.WriteLine("Worker Should Improve His Speed.");
            }
            if (time >= 4 && time >= 5)
            {
                Console.WriteLine("Worker Is Given Training To Improve His Speed.");
            }
            if (time > 5)
            {
                Console.WriteLine("Worker Should Leave The Company.");
            }
            Console.ReadKey();
        }
    }
}

