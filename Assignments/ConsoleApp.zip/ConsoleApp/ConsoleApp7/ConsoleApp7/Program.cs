﻿/*Structs with arguments */
using System;
struct str
{
    int a, b;
    public str(int x, int y)
 a = x;
 b = y;
 }
public int sum ()
{
    return (a + b);
}
}
class student
{
    public static void Main()
    {
        str obj = new str();
        int c = obj.sum();
        Console.WriteLine("Sum = " + c);
    }
}
