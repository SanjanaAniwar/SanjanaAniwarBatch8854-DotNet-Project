﻿using System;
namespace CSharpFeatures
{
    class ImplicitTypedExample
    {
        public static void Main()
        {
            var a = 20;
            var s = "javatpoint";
            var arr = new[] { 1, 2, 3 };
            Console.WriteLine(a);
            Console.WriteLine(s);
            Console.WriteLine(arr[2]);
        }

    }
}
