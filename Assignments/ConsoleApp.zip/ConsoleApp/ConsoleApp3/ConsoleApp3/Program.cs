﻿using System;

namespace ConsoleApp3
{
    class Demo
    {
        dynamic Data = 12;
        public int Method(int a, int b)
        {
            return (a + b) * Data;
        }
    }

    class program
    {
        static void Main(string[] args)
        {
            Demo obj = new Demo();
            dynamic value1;
            dynamic value2;
            Console.WriteLine("Enter first value1:");
            value1 = Console.ReadLine();
            int a = Convert.ToInt32(value1);
            Console.WriteLine("Enter second value2:");
            value2 = Console.ReadLine();
            int b = Convert.ToInt32(value2);

            Console.WriteLine("The Output is:" + obj.Method(a, b));
            Console.ReadLine();

        }
    }
}
