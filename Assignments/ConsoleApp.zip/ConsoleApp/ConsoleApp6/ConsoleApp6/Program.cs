﻿/*Structs and Constructors */
using System;
struct str
{
    int a, b;
    public str(int a, int b) //Error, we can't used default structure of constructor
  a = 100;
  b = 200;
 }
public void show()
{ 

    int c = a + b;
    Console.WriteLine("Sum=" + c);
c
}
class student
{
    public static void Main()
    {
        str obj = new str();
        obj.sum();
    }
}

