﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;


namespace Online_Food_Ordering_System
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private class frmMain
        {
            public frmMain()
            {
            }

            internal object Show()
            {
                throw new NotImplementedException();
            }
        }

        private void bindingSource1_CurrentChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection sqlcon = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Login.mdf;Integrated Security=True");
                string query = "Select * from logintable where Username = '" + textBox1.Text.Trim() + "'and Password = '" + textBox2.Text.Trim() + "'";
                SqlDataAdapter sda = new SqlDataAdapter(query, sqlcon);
                DataTable Table_1 = new DataTable();
                sda.Fill(Table_1);
                if (Table_1.Rows.Count == 1)
                {
                    frmMain objFrmMain = new frmMain();
                    this.Hide();
                    object p = objFrmMain.Show();


                }
                else
                {
                    MessageBox.Show("Invalid Username or Password");
                }


            }
            catch (SqlException odbcEx)
            {
                // Handle more specific SqlException exception here.  
            }
            using (Dashboard da = new Dashboard())
            {
                da.ShowDialog();
            }
        }
    }
}

